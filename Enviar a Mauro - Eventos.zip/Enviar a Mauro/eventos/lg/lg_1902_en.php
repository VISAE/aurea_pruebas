<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Eventos';
$ETI['titulo_sector2']='Eventos';
$ETI['titulo_sector93']='Consecutivo changue';
$ETI['titulo_1902']='Eventos';
$ETI['sigla_1902']='Eventos';
$ETI['bt_ter_buscar']='Search document';
$ETI['bt_ter_crear']='Make document';
$ETI['lnk_cargar']='Edit';
$ETI['even02consec']='Consec';
$ETI['even02id']='Id';
$ETI['even02tipo']='Tipo';
$ETI['even02categoria']='Categoria';
$ETI['even02estado']='Estado';
$ETI['even02publicado']='Publicado';
$ETI['even02nombre']='Nombre';
$ETI['even02idzona']='Zona';
$ETI['even02idcead']='Cead';
$ETI['even02peraca']='Peraca';
$ETI['even02lugar']='Lugar';
$ETI['even02inifecha']='Inifecha';
$ETI['even02inihora']='Inihora';
$ETI['even02iniminuto']='Iniminuto';
$ETI['even02finfecha']='Finfecha';
$ETI['even02finhora']='Finhora';
$ETI['even02finminuto']='Finminuto';
$ETI['even02idorganizador']='Organizador';
$ETI['even02contacto']='Contacto';
$ETI['even02insfechaini']='Insfechaini';
$ETI['even02insfechafin']='Insfechafin';
$ETI['even02idcertificado']='Certificado';
$ETI['even02idrubrica']='Rubrica';
$ETI['even02detalle']='Detalle';
$ETI['even02url']='URL';

$ERR['even02consec']='Is necessary the data '.$ETI['even02consec'];
$ERR['even02id']='Is necessary the data '.$ETI['even02id'];
$ERR['even02tipo']='Is necessary the data '.$ETI['even02tipo'];
$ERR['even02categoria']='Is necessary the data '.$ETI['even02categoria'];
$ERR['even02estado']='Is necessary the data '.$ETI['even02estado'];
$ERR['even02publicado']='Is necessary the data '.$ETI['even02publicado'];
$ERR['even02nombre']='Is necessary the data '.$ETI['even02nombre'];
$ERR['even02idzona']='Is necessary the data '.$ETI['even02idzona'];
$ERR['even02idcead']='Is necessary the data '.$ETI['even02idcead'];
$ERR['even02peraca']='Is necessary the data '.$ETI['even02peraca'];
$ERR['even02lugar']='Is necessary the data '.$ETI['even02lugar'];
$ERR['even02inifecha']='Is necessary the data '.$ETI['even02inifecha'];
$ERR['even02inihora']='Is necessary the data '.$ETI['even02inihora'];
$ERR['even02iniminuto']='Is necessary the data '.$ETI['even02iniminuto'];
$ERR['even02finfecha']='Is necessary the data '.$ETI['even02finfecha'];
$ERR['even02finhora']='Is necessary the data '.$ETI['even02finhora'];
$ERR['even02finminuto']='Is necessary the data '.$ETI['even02finminuto'];
$ERR['even02idorganizador']='Is necessary the data '.$ETI['even02idorganizador'];
$ERR['even02contacto']='Is necessary the data '.$ETI['even02contacto'];
$ERR['even02insfechaini']='Is necessary the data '.$ETI['even02insfechaini'];
$ERR['even02insfechafin']='Is necessary the data '.$ETI['even02insfechafin'];
$ERR['even02idcertificado']='Is necessary the data '.$ETI['even02idcertificado'];
$ERR['even02idrubrica']='Is necessary the data '.$ETI['even02idrubrica'];
$ERR['even02detalle']='Is necessary the data '.$ETI['even02detalle'];
?>