<?php
$APP=new stdclass();
$APP->idsistema=1;
$APP->rutacomun='../ulib/';
$APP->tipo_doc='CC';
$APP->utf8=0;
$APP->tiempolimite=60;
$APP->dbhost='129.191.25.173';
$APP->dbpuerto='30000';
$APP->dbuser='unadsys';
$APP->dbpass='vn4D2y2!!';
$APP->dbname='unadsys';
?>
