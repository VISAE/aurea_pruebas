<html>
<head>
<title>No tiene permiso para estar en este sitio </title>
</head>
<body>
<meta http-equiv="refresh" content="5; url=index.php">
<div align="center">
No tiene permiso para estar en este sitio <a href="index.php">Volver al inicio</a>
</div>
</body>
