<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1905']='Noticias';
$ETI['sigla_1905']='Noticias';
$ETI['bt_mini_guardar_1905']='Salvar Noticias';
$ETI['bt_mini_limpiar_1905']='Limpar Noticias';
$ETI['bt_mini_eliminar_1905']='Remover Noticias';
$ETI['si']='Sim';
$ETI['no']='N&atilde;o';
$ETI['lnk_cargar']='Editar';
$ETI['even05idevento']='Evento';
$ETI['even05consec']='Consec';
$ETI['even05id']='Id';
$ETI['even05fecha']='Fecha';
$ETI['even05publicar']='Publicar';
$ETI['even05idtercero']='Tercero';
$ETI['even05noticia']='Noticia';

$ERR['even05idevento']='&Eacute; necess&aacute;rio o dado '.$ETI['even05idevento'];
$ERR['even05consec']='&Eacute; necess&aacute;rio o dado '.$ETI['even05consec'];
$ERR['even05id']='&Eacute; necess&aacute;rio o dado '.$ETI['even05id'];
$ERR['even05fecha']='&Eacute; necess&aacute;rio o dado '.$ETI['even05fecha'];
$ERR['even05publicar']='&Eacute; necess&aacute;rio o dado '.$ETI['even05publicar'];
$ERR['even05idtercero']='&Eacute; necess&aacute;rio o dado '.$ETI['even05idtercero'];
$ERR['even05noticia']='&Eacute; necess&aacute;rio o dado '.$ETI['even05noticia'];
?>