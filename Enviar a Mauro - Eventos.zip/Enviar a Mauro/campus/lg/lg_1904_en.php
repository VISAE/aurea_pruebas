<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1904']='Participantes';
$ETI['sigla_1904']='Participantes';
$ETI['bt_mini_guardar_1904']='Save Participantes';
$ETI['bt_mini_limpiar_1904']='Clear Participantes';
$ETI['bt_mini_eliminar_1904']='Delete Participantes';
$ETI['si']='Yes';
$ETI['no']='No';
$ETI['lnk_cargar']='Edit';
$ETI['even04idevento']='Evento';
$ETI['even04idparticipante']='Participante';
$ETI['even04id']='Id';
$ETI['even04institucion']='Institucion';
$ETI['even04cargo']='Cargo';
$ETI['even04correo']='Correo';
$ETI['even04telefono']='Telefono';
$ETI['even04estadoasistencia']='Estadoasistencia';
$ETI['msg_infoplanoparticipante']='Para subir participantes masivamente ingrese los numeros de documento de los usuarios en la primer columna de un archivo MsExcel, seleccione el estado de asistencia que desea asignar y luego haga clic en el boton subir.';
$ETI['bloque_mis_eventos']='Mis Eventos';
$ETI['bloque_eventos_futuros']='Eventos Futuros';

$ERR['even04idevento']='Is necessary the data '.$ETI['even04idevento'];
$ERR['even04idparticipante']='Is necessary the data '.$ETI['even04idparticipante'];
$ERR['even04id']='Is necessary the data '.$ETI['even04id'];
$ERR['even04institucion']='Is necessary the data '.$ETI['even04institucion'];
$ERR['even04cargo']='Is necessary the data '.$ETI['even04cargo'];
$ERR['even04correo']='Is necessary the data '.$ETI['even04correo'];
$ERR['even04telefono']='Is necessary the data '.$ETI['even04telefono'];
$ERR['even04estadoasistencia']='Is necessary the data '.$ETI['even04estadoasistencia'];
?>