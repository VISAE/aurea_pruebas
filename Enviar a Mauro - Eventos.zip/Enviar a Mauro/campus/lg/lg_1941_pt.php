<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1941']='Categorias';
$ETI['sigla_1941']='Categorias';
$ETI['bt_mini_guardar_1941']='Salvar Categorias';
$ETI['bt_mini_limpiar_1941']='Limpar Categorias';
$ETI['bt_mini_eliminar_1941']='Remover Categorias';
$ETI['si']='Sim';
$ETI['no']='N&atilde;o';
$ETI['lnk_cargar']='Editar';
$ETI['even41idtipoevento']='Tipoevento';
$ETI['even41consec']='Consec';
$ETI['even41id']='Id';
$ETI['even41activo']='Activo';
$ETI['even41titulo']='Titulo';

$ERR['even41idtipoevento']='&Eacute; necess&aacute;rio o dado '.$ETI['even41idtipoevento'];
$ERR['even41consec']='&Eacute; necess&aacute;rio o dado '.$ETI['even41consec'];
$ERR['even41id']='&Eacute; necess&aacute;rio o dado '.$ETI['even41id'];
$ERR['even41activo']='&Eacute; necess&aacute;rio o dado '.$ETI['even41activo'];
$ERR['even41titulo']='&Eacute; necess&aacute;rio o dado '.$ETI['even41titulo'];
?>