<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1903']='Cursos';
$ETI['sigla_1903']='Cursos';
$ETI['bt_mini_guardar_1903']='Salvar Cursos';
$ETI['bt_mini_limpiar_1903']='Limpar Cursos';
$ETI['bt_mini_eliminar_1903']='Remover Cursos';
$ETI['si']='Sim';
$ETI['no']='N&atilde;o';
$ETI['lnk_cargar']='Editar';
$ETI['even03idevento']='Evento';
$ETI['even03idcurso']='Curso';
$ETI['even03id']='Id';
$ETI['even03vigente']='Vigente';

$ERR['even03idevento']='&Eacute; necess&aacute;rio o dado '.$ETI['even03idevento'];
$ERR['even03idcurso']='&Eacute; necess&aacute;rio o dado '.$ETI['even03idcurso'];
$ERR['even03id']='&Eacute; necess&aacute;rio o dado '.$ETI['even03id'];
$ERR['even03vigente']='&Eacute; necess&aacute;rio o dado '.$ETI['even03vigente'];
?>