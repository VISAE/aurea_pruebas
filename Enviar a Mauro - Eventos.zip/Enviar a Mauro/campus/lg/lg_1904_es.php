<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1904']='Participantes';
$ETI['sigla_1904']='Participantes';
$ETI['bt_mini_guardar_1904']='Guardar Participantes';
$ETI['bt_mini_limpiar_1904']='Limpiar Participantes';
$ETI['bt_mini_eliminar_1904']='Eliminar Participantes';
$ETI['si']='Si';
$ETI['no']='No';
$ETI['lnk_cargar']='Editar';
$ETI['even04idevento']='Evento';
$ETI['even04idparticipante']='Participante';
$ETI['even04id']='Ref :';
$ETI['even04institucion']='Institucion';
$ETI['even04cargo']='Cargo';
$ETI['even04correo']='Correo';
$ETI['even04telefono']='Telefono';
$ETI['even04estadoasistencia']='Estado asistencia';
$ETI['msg_infoplanoparticipante']='Para subir participantes masivamente ingrese los numeros de documento de los usuarios en la primer columna de un archivo MsExcel, seleccione el estado de asistencia que desea asignar y luego haga clic en el boton subir.';
$ETI['bloque_mis_eventos']='Mis Eventos';
$ETI['bloque_mis_eventos_futuros']='Eventos a los que asistir&eacute;';
$ETI['bloque_mis_eventos_actuales']='Eventos para el d&iacute;a de hoy';
$ETI['bloque_mis_eventos_pasados']='Eventos en los que particip&eacute;';
$ETI['bloque_eventos_futuros']='Eventos a los que puedo asistir';
$ETI['lnk_futuro']='No Asistir&eacute;';
$ETI['lnk_presente']='Confirmar';
$ETI['lnk_pasado']='Certificado';
$ETI['lnk_bfuturo']='Inscribirme';
$ETI['presencial']='Presencial';
$ETI['virtual']='Virtual';

$ERR['even04idevento']='Necesita el dato '.$ETI['even04idevento'];
$ERR['even04idparticipante']='Necesita el dato '.$ETI['even04idparticipante'];
$ERR['even04id']='Necesita el dato '.$ETI['even04id'];
$ERR['even04institucion']='Necesita el dato '.$ETI['even04institucion'];
$ERR['even04cargo']='Necesita el dato '.$ETI['even04cargo'];
$ERR['even04correo']='Necesita el dato '.$ETI['even04correo'];
$ERR['even04telefono']='Necesita el dato '.$ETI['even04telefono'];
$ERR['even04estadoasistencia']='Necesita el dato '.$ETI['even04estadoasistencia'];
$ERR['falla_guardar']='Falla al guardar';
?>