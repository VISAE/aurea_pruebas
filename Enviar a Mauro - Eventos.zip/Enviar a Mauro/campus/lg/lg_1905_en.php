<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1905']='Noticias';
$ETI['sigla_1905']='Noticias';
$ETI['bt_mini_guardar_1905']='Save Noticias';
$ETI['bt_mini_limpiar_1905']='Clear Noticias';
$ETI['bt_mini_eliminar_1905']='Delete Noticias';
$ETI['si']='Yes';
$ETI['no']='No';
$ETI['lnk_cargar']='Edit';
$ETI['even05idevento']='Evento';
$ETI['even05consec']='Consec';
$ETI['even05id']='Id';
$ETI['even05fecha']='Fecha';
$ETI['even05publicar']='Publicar';
$ETI['even05idtercero']='Tercero';
$ETI['even05noticia']='Noticia';

$ERR['even05idevento']='Is necessary the data '.$ETI['even05idevento'];
$ERR['even05consec']='Is necessary the data '.$ETI['even05consec'];
$ERR['even05id']='Is necessary the data '.$ETI['even05id'];
$ERR['even05fecha']='Is necessary the data '.$ETI['even05fecha'];
$ERR['even05publicar']='Is necessary the data '.$ETI['even05publicar'];
$ERR['even05idtercero']='Is necessary the data '.$ETI['even05idtercero'];
$ERR['even05noticia']='Is necessary the data '.$ETI['even05noticia'];
?>