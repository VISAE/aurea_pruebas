<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1903']='Cursos';
$ETI['sigla_1903']='Cursos';
$ETI['bt_mini_guardar_1903']='Save Cursos';
$ETI['bt_mini_limpiar_1903']='Clear Cursos';
$ETI['bt_mini_eliminar_1903']='Delete Cursos';
$ETI['si']='Yes';
$ETI['no']='No';
$ETI['lnk_cargar']='Edit';
$ETI['even03idevento']='Evento';
$ETI['even03idcurso']='Curso';
$ETI['even03id']='Id';
$ETI['even03vigente']='Vigente';

$ERR['even03idevento']='Is necessary the data '.$ETI['even03idevento'];
$ERR['even03idcurso']='Is necessary the data '.$ETI['even03idcurso'];
$ERR['even03id']='Is necessary the data '.$ETI['even03id'];
$ERR['even03vigente']='Is necessary the data '.$ETI['even03vigente'];
?>