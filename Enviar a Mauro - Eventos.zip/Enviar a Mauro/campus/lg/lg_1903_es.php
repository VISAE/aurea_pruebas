<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1903']='Cursos';
$ETI['sigla_1903']='Cursos';
$ETI['bt_mini_guardar_1903']='Guardar Cursos';
$ETI['bt_mini_limpiar_1903']='Limpiar Cursos';
$ETI['bt_mini_eliminar_1903']='Eliminar Cursos';
$ETI['si']='Si';
$ETI['no']='No';
$ETI['lnk_cargar']='Editar';
$ETI['even03idevento']='Evento';
$ETI['even03idcurso']='Curso';
$ETI['even03id']='Ref :';
$ETI['even03vigente']='Vigente';

$ERR['even03idevento']='Necesita el dato '.$ETI['even03idevento'];
$ERR['even03idcurso']='Necesita el dato '.$ETI['even03idcurso'];
$ERR['even03id']='Necesita el dato '.$ETI['even03id'];
$ERR['even03vigente']='Necesita el dato '.$ETI['even03vigente'];
?>