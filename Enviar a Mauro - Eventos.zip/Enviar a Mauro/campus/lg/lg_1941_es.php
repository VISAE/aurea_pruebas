<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1941']='Categorias';
$ETI['sigla_1941']='Categorias';
$ETI['bt_mini_guardar_1941']='Guardar Categorias';
$ETI['bt_mini_limpiar_1941']='Limpiar Categorias';
$ETI['bt_mini_eliminar_1941']='Eliminar Categorias';
$ETI['si']='Si';
$ETI['no']='No';
$ETI['lnk_cargar']='Editar';
$ETI['even41idtipoevento']='Tipoevento';
$ETI['even41consec']='Consecutivo';
$ETI['even41id']='Ref :';
$ETI['even41activo']='Activo';
$ETI['even41titulo']='Titulo';

$ERR['even41idtipoevento']='Necesita el dato '.$ETI['even41idtipoevento'];
$ERR['even41consec']='Necesita el dato '.$ETI['even41consec'];
$ERR['even41id']='Necesita el dato '.$ETI['even41id'];
$ERR['even41activo']='Necesita el dato '.$ETI['even41activo'];
$ERR['even41titulo']='Necesita el dato '.$ETI['even41titulo'];
?>