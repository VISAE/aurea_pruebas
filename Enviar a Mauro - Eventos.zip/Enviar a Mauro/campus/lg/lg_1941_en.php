<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Model Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1941']='Categorias';
$ETI['sigla_1941']='Categorias';
$ETI['bt_mini_guardar_1941']='Save Categorias';
$ETI['bt_mini_limpiar_1941']='Clear Categorias';
$ETI['bt_mini_eliminar_1941']='Delete Categorias';
$ETI['si']='Yes';
$ETI['no']='No';
$ETI['lnk_cargar']='Edit';
$ETI['even41idtipoevento']='Tipoevento';
$ETI['even41consec']='Consec';
$ETI['even41id']='Id';
$ETI['even41activo']='Activo';
$ETI['even41titulo']='Titulo';

$ERR['even41idtipoevento']='Is necessary the data '.$ETI['even41idtipoevento'];
$ERR['even41consec']='Is necessary the data '.$ETI['even41consec'];
$ERR['even41id']='Is necessary the data '.$ETI['even41id'];
$ERR['even41activo']='Is necessary the data '.$ETI['even41activo'];
$ERR['even41titulo']='Is necessary the data '.$ETI['even41titulo'];
?>