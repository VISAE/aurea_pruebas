<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['titulo_1905']='Noticias';
$ETI['sigla_1905']='Noticias';
$ETI['bt_mini_guardar_1905']='Guardar Noticias';
$ETI['bt_mini_limpiar_1905']='Limpiar Noticias';
$ETI['bt_mini_eliminar_1905']='Eliminar Noticias';
$ETI['si']='Si';
$ETI['no']='No';
$ETI['lnk_cargar']='Editar';
$ETI['even05idevento']='Evento';
$ETI['even05consec']='Consecutivo';
$ETI['even05id']='Ref :';
$ETI['even05fecha']='Fecha';
$ETI['even05publicar']='Publicar';
$ETI['even05idtercero']='Tercero';
$ETI['even05noticia']='Noticia';

$ERR['even05idevento']='Necesita el dato '.$ETI['even05idevento'];
$ERR['even05consec']='Necesita el dato '.$ETI['even05consec'];
$ERR['even05id']='Necesita el dato '.$ETI['even05id'];
$ERR['even05fecha']='Necesita el dato '.$ETI['even05fecha'];
$ERR['even05publicar']='Necesita el dato '.$ETI['even05publicar'];
$ERR['even05idtercero']='Necesita el dato '.$ETI['even05idtercero'];
$ERR['even05noticia']='Necesita el dato '.$ETI['even05noticia'];
?>