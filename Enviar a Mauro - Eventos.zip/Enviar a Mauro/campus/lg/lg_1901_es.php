<?php
/*
--- © Angel Mauro Avellaneda Barreto - UNAD - 2019 ---
--- angel.avellaneda@unad.edu.co - http://www.unad.edu.co
--- Modelo Version 2.23.5 Tuesday, August 27, 2019
*/
$ETI['app_nombre']='APP';
$ETI['grupo_nombre']='Grupo';
$ETI['titulo']='Tipos de enventos';
$ETI['titulo_sector2']='Tipos de enventos';
$ETI['titulo_1901']='Tipos de enventos';
$ETI['sigla_1901']='Tipos de enventos';
$ETI['lnk_cargar']='Editar';
$ETI['even01consec']='Consec';
$ETI['even01id']='Id';
$ETI['even01nombre']='Nombre';

$ERR['even01consec']='Necesita el dato '.$ETI['even01consec'];
$ERR['even01id']='Necesita el dato '.$ETI['even01id'];
$ERR['even01nombre']='Necesita el dato '.$ETI['even01nombre'];
?>